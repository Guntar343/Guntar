// commands/prefix/role.js
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');
const { isValidSnowflake } = require('../../utils/helpers');
const logger = require('../../utils/logger');

module.exports = {
  name: 'role',
  description: 'Add or remove a role from a user',
  async execute(message, args) {
    if (!isAdmin(message.member)) {
      return message.reply({ embeds: [errorEmbed('No Permission', 'Only admins can manage roles.')] });
    }

    const [userId, roleId] = args;
    if (!userId || !roleId || !isValidSnowflake(userId) || !isValidSnowflake(roleId)) {
      return message.reply({ embeds: [errorEmbed('Invalid Usage', 'Usage: `.role <USER_ID> <ROLE_ID>`')] });
    }

    const member = await message.guild.members.fetch(userId).catch(() => null);
    if (!member) return message.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')] });

    const role = message.guild.roles.cache.get(roleId);
    if (!role) return message.reply({ embeds: [errorEmbed('Role Not Found', 'That role does not exist.')] });

    const hasRole = member.roles.cache.has(roleId);

    if (hasRole) {
      await member.roles.remove(role);
      await message.reply({ embeds: [successEmbed('Role Removed', `Removed **${role.name}** from ${member}.`)] });
      await logger.log({ action: 'Role Removed', type: 'warning', user: member.user, moderator: message.author, details: `Role **${role.name}** removed` });
    } else {
      await member.roles.add(role);
      await message.reply({ embeds: [successEmbed('Role Added', `Added **${role.name}** to ${member}.`)] });
      await logger.log({ action: 'Role Added', type: 'success', user: member.user, moderator: message.author, details: `Role **${role.name}** added` });
    }
  },
};
