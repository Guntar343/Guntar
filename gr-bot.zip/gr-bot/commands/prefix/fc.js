// commands/prefix/fc.js - Close ticket command
const { tickets } = require('../../database/database');
const { closeTicket } = require('../../services/ticketService');
const { errorEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'fc',
  description: 'Close the current ticket',
  async execute(message) {
    const ticketData = tickets.getByChannel(message.channel.id);

    if (!ticketData) {
      return message.reply({ embeds: [errorEmbed('Not a Ticket', 'This command can only be used inside a ticket channel.')] });
    }

    // Only ticket owner or staff can close
    const isOwner = ticketData.owner_id === message.author.id;
    const isStaff = message.member.permissions.has('ManageChannels');

    if (!isOwner && !isStaff) {
      return message.reply({ embeds: [errorEmbed('No Permission', 'Only the ticket owner or staff can close this ticket.')] });
    }

    await closeTicket({ channel: message.channel, user: message.author, reply: (opts) => message.reply(opts) });
  },
};
