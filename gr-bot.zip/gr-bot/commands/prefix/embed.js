// commands/prefix/embed.js - Embed Builder Command (! prefix for staff)
const { createEmbed, errorEmbed } = require('../../utils/embeds');
const { isStaff } = require('../../utils/permissions');
const logger = require('../../utils/logger');
const config = require('../../config/config');

module.exports = {
  name: 'embed',
  prefix: '!', // uses ! prefix instead of .
  description: 'Build and send a styled embed (Staff only)',
  async execute(message, args) {
    if (!isStaff(message.member)) {
      return message.reply({ embeds: [errorEmbed('No Permission', 'Only staff can use the embed builder.')] });
    }

    // Format: !embed Title | Subtitle | Content
    const fullContent = message.content.slice('!embed '.length).trim();
    const parts = fullContent.split('|').map(p => p.trim());

    if (parts.length < 3) {
      return message.reply({
        embeds: [errorEmbed('Invalid Format', 'Usage: `!embed Title | Subtitle | Content`')],
      });
    }

    const [title, subtitle, ...contentParts] = parts;
    const content = contentParts.join(' | ');

    const embed = createEmbed({
      title,
      description: `*${subtitle}*\n\n${content}`,
      color: config.embedColor.primary,
    });

    // Delete original command message
    await message.delete().catch(() => {});

    await message.channel.send({ embeds: [embed] });

    await logger.log({
      action: 'Embed Created',
      type: 'info',
      user: message.author,
      details: `Embed sent in ${message.channel}\n**Title:** ${title}\n**Subtitle:** ${subtitle}`,
    });
  },
};
