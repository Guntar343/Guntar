// commands/prefix/daily.js
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { daily, formatBalance } = require('../../services/economyService');
const { formatDuration } = require('../../utils/helpers');
const config = require('../../config/config');

module.exports = {
  name: 'daily',
  description: 'Claim your daily reward',
  async execute(message) {
    const result = await daily(message.author.id, message.guild.id, message.author);

    if (!result.success) {
      return message.reply({
        embeds: [errorEmbed('Already Claimed', `You already claimed your daily reward! Come back in **${formatDuration(result.remaining)}**.`)],
      });
    }

    await message.reply({
      embeds: [successEmbed('Daily Reward!', `You received ${formatBalance(result.amount)}! Come back in 24 hours for more.`)],
    });
  },
};
