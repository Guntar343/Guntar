// commands/prefix/balance.js
const { economy } = require('../../database/database');
const { createEmbed } = require('../../utils/embeds');
const { formatBalance } = require('../../services/economyService');
const config = require('../../config/config');

module.exports = {
  name: 'balance',
  aliases: ['bal', 'money'],
  description: 'Check your balance or another user\'s balance',
  async execute(message, args) {
    let target = message.mentions.users.first();
    if (!target && args[0]) {
      target = await message.client.users.fetch(args[0]).catch(() => null);
    }
    target = target || message.author;

    const record = economy.get(target.id, message.guild.id);

    const embed = createEmbed({
      title: `${config.economy.currency} Balance`,
      description: `**${target.tag}**'s wallet`,
      color: config.embedColor.primary,
      thumbnail: target.displayAvatarURL({ dynamic: true }),
      fields: [
        { name: '💰 Balance', value: formatBalance(record.balance), inline: true },
        { name: '📈 Total Earned', value: formatBalance(record.total_earned), inline: true },
      ],
    });

    await message.reply({ embeds: [embed] });
  },
};
