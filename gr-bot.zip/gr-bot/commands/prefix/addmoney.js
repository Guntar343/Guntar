// commands/prefix/addmoney.js
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { adminAdd, adminRemove, formatBalance } = require('../../services/economyService');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  name: 'addmoney',
  aliases: ['givemoney'],
  description: 'Add money to a user (Admin only)',
  async execute(message, args) {
    if (!isAdmin(message.member)) {
      return message.reply({ embeds: [errorEmbed('No Permission', 'Only admins can use this command.')] });
    }

    const target = message.mentions.users.first() || await message.client.users.fetch(args[0]).catch(() => null);
    const amount = parseInt(args[1] || args[0]);

    if (!target) return message.reply({ embeds: [errorEmbed('Invalid User', 'Please mention a valid user.')] });
    if (!amount || isNaN(amount) || amount <= 0) return message.reply({ embeds: [errorEmbed('Invalid Amount', 'Please provide a valid amount.')] });

    const result = await adminAdd(target.id, message.guild.id, amount, target, message.author);
    if (!result.success) return message.reply({ embeds: [errorEmbed('Failed', result.error)] });

    await message.reply({ embeds: [successEmbed('Money Added', `Added ${formatBalance(amount)} to ${target}.`)] });
  },
};
