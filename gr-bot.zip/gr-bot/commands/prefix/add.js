// commands/prefix/add.js - Add user to ticket
const { PermissionFlagsBits } = require('discord.js');
const { tickets } = require('../../database/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isValidSnowflake } = require('../../utils/helpers');
const logger = require('../../utils/logger');

module.exports = {
  name: 'add',
  description: 'Add a user to the current ticket',
  async execute(message, args) {
    const ticketData = tickets.getByChannel(message.channel.id);

    if (!ticketData) {
      return message.reply({ embeds: [errorEmbed('Not a Ticket', 'This command can only be used inside a ticket channel.')] });
    }

    const userId = args[0];
    if (!userId || !isValidSnowflake(userId)) {
      return message.reply({ embeds: [errorEmbed('Invalid Usage', 'Usage: `.add <USER_ID>`')] });
    }

    const member = await message.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      return message.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')] });
    }

    await message.channel.permissionOverwrites.edit(member, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
    });

    await message.reply({ embeds: [successEmbed('User Added', `${member} has been added to this ticket.`)] });

    await logger.log({
      action: 'Ticket: User Added',
      type: 'info',
      user: message.author,
      details: `**${member.user.tag}** was added to ticket **${message.channel.name}**`,
    });
  },
};
