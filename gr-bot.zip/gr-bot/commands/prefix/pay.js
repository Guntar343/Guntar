// commands/prefix/pay.js
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { pay, formatBalance } = require('../../services/economyService');

module.exports = {
  name: 'pay',
  description: 'Send money to another user',
  async execute(message, args) {
    const target = message.mentions.users.first() || await message.client.users.fetch(args[0]).catch(() => null);
    const amount = parseInt(args[1] || args[0]);

    if (!target || target.bot) return message.reply({ embeds: [errorEmbed('Invalid User', 'Please mention a valid user.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [errorEmbed('Invalid', "You can't pay yourself.")] });
    if (!amount || isNaN(amount) || amount <= 0) return message.reply({ embeds: [errorEmbed('Invalid Amount', 'Please provide a valid amount.')] });

    const result = await pay(message.author.id, target.id, message.guild.id, amount, message.author, target);

    if (!result.success) return message.reply({ embeds: [errorEmbed('Transaction Failed', result.error)] });

    await message.reply({ embeds: [successEmbed('Payment Sent!', `You sent ${formatBalance(amount)} to ${target}.`)] });
  },
};
