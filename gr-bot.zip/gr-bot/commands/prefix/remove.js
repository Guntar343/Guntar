// commands/prefix/remove.js - Remove user from ticket
const { tickets } = require('../../database/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isValidSnowflake } = require('../../utils/helpers');
const logger = require('../../utils/logger');

module.exports = {
  name: 'remove',
  description: 'Remove a user from the current ticket',
  async execute(message, args) {
    const ticketData = tickets.getByChannel(message.channel.id);

    if (!ticketData) {
      return message.reply({ embeds: [errorEmbed('Not a Ticket', 'This command can only be used inside a ticket channel.')] });
    }

    const userId = args[0];
    if (!userId || !isValidSnowflake(userId)) {
      return message.reply({ embeds: [errorEmbed('Invalid Usage', 'Usage: `.remove <USER_ID>`')] });
    }

    // Prevent removing the ticket owner
    if (userId === ticketData.owner_id) {
      return message.reply({ embeds: [errorEmbed('Cannot Remove', 'You cannot remove the ticket owner.')] });
    }

    const member = await message.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      return message.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')] });
    }

    await message.channel.permissionOverwrites.edit(member, {
      ViewChannel: false,
    });

    await message.reply({ embeds: [successEmbed('User Removed', `${member} has been removed from this ticket.`)] });

    await logger.log({
      action: 'Ticket: User Removed',
      type: 'warning',
      user: message.author,
      details: `**${member.user.tag}** was removed from ticket **${message.channel.name}**`,
    });
  },
};
