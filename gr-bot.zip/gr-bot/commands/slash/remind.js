// commands/slash/remind.js
const { SlashCommandBuilder } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { reminders } = require('../../database/database');
const { parseDuration, formatDuration, discordTimestamp } = require('../../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Set a reminder')
    .addStringOption(opt => opt.setName('time').setDescription('When to remind you (e.g. 10m, 2h, 1d)').setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('What to remind you about').setRequired(true)),

  async execute(interaction) {
    const timeStr = interaction.options.getString('time');
    const message = interaction.options.getString('message');
    const durationMs = parseDuration(timeStr);

    if (!durationMs || durationMs < 10000) {
      return interaction.reply({ embeds: [errorEmbed('Invalid Time', 'Minimum reminder time is 10 seconds. Use formats like `10m`, `2h`, `1d`.')], ephemeral: true });
    }

    const remindAt = Date.now() + durationMs;
    reminders.create(interaction.user.id, interaction.channelId, interaction.guildId, message, remindAt);

    await interaction.reply({
      embeds: [successEmbed('Reminder Set!', `I'll remind you in **${formatDuration(durationMs)}** (${discordTimestamp(remindAt, 'R')})\n**Message:** ${message}`)],
      ephemeral: true,
    });
  },
};
