// commands/slash/poll.js
const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll')
    .addStringOption(opt => opt.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(opt => opt.setName('options').setDescription('Options separated by | (e.g. Yes|No|Maybe). Max 9.').setRequired(false)),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const optionsRaw = interaction.options.getString('options');

    const numberEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];

    let description;
    let reactions;

    if (optionsRaw) {
      const options = optionsRaw.split('|').map(o => o.trim()).filter(Boolean).slice(0, 9);
      if (options.length < 2) {
        return interaction.reply({ content: 'Please provide at least 2 options separated by `|`.', ephemeral: true });
      }
      description = `**${question}**\n\n` + options.map((o, i) => `${numberEmojis[i]} ${o}`).join('\n');
      reactions = numberEmojis.slice(0, options.length);
    } else {
      description = `**${question}**`;
      reactions = ['✅', '❌'];
    }

    const embed = createEmbed({
      title: '📊 Poll',
      description,
      color: config.embedColor.info,
      fields: [{ name: '📌 Created by', value: `${interaction.user}`, inline: true }],
    });

    const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
    for (const emoji of reactions) {
      await msg.react(emoji).catch(() => {});
    }
  },
};
