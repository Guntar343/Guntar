// commands/slash/avatar.js
const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Get a user\'s avatar')
    .addUserOption(opt => opt.setName('user').setDescription('User to get avatar from').setRequired(false)),

  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = createEmbed({
      title: `🖼️ ${user.tag}'s Avatar`,
      image: avatarUrl,
      url: avatarUrl,
    });

    await interaction.reply({ embeds: [embed] });
  },
};
