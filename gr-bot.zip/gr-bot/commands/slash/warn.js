// commands/slash/warn.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { warn } = require('../../services/moderationService');
const { moderation } = require('../../database/database');
const { isMod } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption(opt => opt.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    if (!isMod(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('No Permission', 'You need Mod or higher.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'Could not find that user.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('Invalid', "You can't warn yourself.")], ephemeral: true });

    await interaction.deferReply({ ephemeral: true });

    const warnCount = await warn(interaction.guild, target, interaction.user, reason);

    await interaction.editReply({
      embeds: [successEmbed('Member Warned', `**${target.tag}** has been warned.\n**Reason:** ${reason}\n**Total Warnings:** ${warnCount}`)],
    });
  },
};
