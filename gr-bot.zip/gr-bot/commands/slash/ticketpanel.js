// commands/slash/ticketpanel.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createTicketPanel } = require('../../services/ticketService');
const { errorEmbed } = require('../../utils/embeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketpanel')
    .setDescription('Send the ticket creation panel')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('No Permission', 'Only admins can send the ticket panel.')], ephemeral: true });
    }

    const panel = createTicketPanel();
    await interaction.channel.send(panel);
    await interaction.reply({ content: '✅ Ticket panel sent!', ephemeral: true });
  },
};
