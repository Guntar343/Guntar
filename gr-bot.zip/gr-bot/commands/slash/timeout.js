// commands/slash/timeout.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { timeout } = require('../../services/moderationService');
const { parseDuration, formatDuration } = require('../../utils/helpers');
const { isMod } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a member')
    .addUserOption(opt => opt.setName('user').setDescription('User to timeout').setRequired(true))
    .addStringOption(opt => opt.setName('duration').setDescription('Duration e.g. 10m, 2h, 1d').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    if (!isMod(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('No Permission', 'You need Mod or higher.')], ephemeral: true });
    }

    const target = interaction.options.getMember('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const durationMs = parseDuration(durationStr);

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (!durationMs || durationMs < 1000) return interaction.reply({ embeds: [errorEmbed('Invalid Duration', 'Use formats like `10m`, `2h`, `1d`.')], ephemeral: true });
    if (durationMs > 2419200000) return interaction.reply({ embeds: [errorEmbed('Too Long', 'Maximum timeout duration is 28 days.')], ephemeral: true });

    await interaction.deferReply({ ephemeral: true });

    try {
      await timeout(interaction.guild, target, interaction.user, durationMs, reason);
      await interaction.editReply({
        embeds: [successEmbed('Member Timed Out', `**${target.user.tag}** has been timed out for **${formatDuration(durationMs)}**.\n**Reason:** ${reason}`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', err.message)] });
    }
  },
};
