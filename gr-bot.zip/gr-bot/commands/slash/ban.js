// commands/slash/ban.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { ban } = require('../../services/moderationService');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption(opt => opt.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for ban').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('No Permission', 'You need Administrator to ban members.')], ephemeral: true });
    }

    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!target) return interaction.reply({ embeds: [errorEmbed('User Not Found', 'That user is not in this server.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('Invalid', "You can't ban yourself.")], ephemeral: true });
    if (!target.bannable) return interaction.reply({ embeds: [errorEmbed('Cannot Ban', 'I cannot ban this user due to role hierarchy.')], ephemeral: true });

    await interaction.deferReply({ ephemeral: true });

    try {
      await ban(interaction.guild, target, interaction.user, reason);
      await interaction.editReply({
        embeds: [successEmbed('Member Banned', `**${target.user.tag}** has been banned.\n**Reason:** ${reason}`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Error', err.message)] });
    }
  },
};
