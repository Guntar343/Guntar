// commands/slash/serverinfo.js
const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');
const { discordTimestamp } = require('../../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Get information about this server'),

  async execute(interaction) {
    const guild = interaction.guild;
    await guild.fetch();

    const embed = createEmbed({
      title: `🏠 ${guild.name}`,
      thumbnail: guild.iconURL({ dynamic: true, size: 256 }),
      image: guild.bannerURL({ size: 1024 }),
      fields: [
        { name: '🆔 Server ID', value: guild.id, inline: true },
        { name: '👑 Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: '📅 Created', value: discordTimestamp(guild.createdAt, 'D'), inline: true },
        { name: '👥 Members', value: `${guild.memberCount}`, inline: true },
        { name: '💬 Channels', value: `${guild.channels.cache.size}`, inline: true },
        { name: '🎭 Roles', value: `${guild.roles.cache.size}`, inline: true },
        { name: '😀 Emojis', value: `${guild.emojis.cache.size}`, inline: true },
        { name: '📈 Boost Level', value: `Level ${guild.premiumTier}`, inline: true },
        { name: '🚀 Boosts', value: `${guild.premiumSubscriptionCount}`, inline: true },
        { name: '🔒 Verification', value: guild.verificationLevel.toString(), inline: true },
      ],
    });

    await interaction.reply({ embeds: [embed] });
  },
};
