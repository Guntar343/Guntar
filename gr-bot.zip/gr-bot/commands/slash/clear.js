// commands/slash/clear.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const logger = require('../../utils/logger');
const { isMod } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Delete a number of messages from this channel')
    .addIntegerOption(opt =>
      opt.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100),
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason for clearing').setRequired(false),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    if (!isMod(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('No Permission', 'You need Mod or Admin role to use this command.')], ephemeral: true });
    }

    const amount = interaction.options.getInteger('amount');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    await interaction.deferReply({ ephemeral: true });

    try {
      const deleted = await interaction.channel.bulkDelete(amount, true);

      await interaction.editReply({
        embeds: [successEmbed('Messages Cleared', `Successfully deleted **${deleted.size}** messages.\n**Reason:** ${reason}`)],
      });

      await logger.log({
        action: '🧹 Messages Cleared',
        type: 'warning',
        user: interaction.user,
        details: `Deleted **${deleted.size}** messages in ${interaction.channel}\n**Reason:** ${reason}`,
      });
    } catch (err) {
      await interaction.editReply({
        embeds: [errorEmbed('Error', `Failed to delete messages: ${err.message}`)],
      });
    }
  },
};
