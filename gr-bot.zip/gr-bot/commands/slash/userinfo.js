// commands/slash/userinfo.js
const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');
const { moderation } = require('../../database/database');
const { discordTimestamp } = require('../../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Get information about a user')
    .addUserOption(opt => opt.setName('user').setDescription('User to look up (defaults to you)').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getMember('user') || interaction.member;
    const user = target.user;

    const warnings = moderation.getWarningCount(user.id, interaction.guild.id);
    const cases = moderation.getCases(user.id, interaction.guild.id);
    const roles = target.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => `${r}`).slice(0, 10).join(' ') || 'None';

    const embed = createEmbed({
      title: `👤 ${user.tag}`,
      thumbnail: user.displayAvatarURL({ dynamic: true, size: 256 }),
      fields: [
        { name: '🆔 User ID', value: user.id, inline: true },
        { name: '🤖 Bot', value: user.bot ? 'Yes' : 'No', inline: true },
        { name: '📅 Account Created', value: discordTimestamp(user.createdAt, 'D'), inline: true },
        { name: '📥 Joined Server', value: target.joinedAt ? discordTimestamp(target.joinedAt, 'D') : 'Unknown', inline: true },
        { name: '⚠️ Warnings', value: `${warnings}`, inline: true },
        { name: '📋 Mod Cases', value: `${cases.length}`, inline: true },
        { name: `🎭 Roles [${target.roles.cache.size - 1}]`, value: roles },
      ],
    });

    await interaction.reply({ embeds: [embed] });
  },
};
