// events/messageCreate.js - Prefix commands + Anti-Spam
const { Events } = require('discord.js');
const config = require('../config/config');
const logger = require('../utils/logger');
const { spamTracking } = require('../database/database');
const { errorEmbed } = require('../utils/embeds');

// In-memory spam cache for fast lookups (backed by DB for restarts)
const spamCache = new Map();

async function handleAntiSpam(message) {
  if (!config.antiSpam.enabled) return false;
  if (message.member.permissions.has('ManageMessages')) return false; // Skip staff

  const key = `${message.author.id}-${message.guild.id}`;
  const now = Date.now();
  const { maxMessages, timeWindow, muteMinutes, warnThreshold } = config.antiSpam;

  // Get or create tracking record
  let tracking = spamCache.get(key) || { count: 0, windowStart: now, warnCount: 0 };

  // Reset window if expired
  if (now - tracking.windowStart > timeWindow) {
    tracking = { count: 0, windowStart: now, warnCount: tracking.warnCount };
  }

  tracking.count++;
  spamCache.set(key, tracking);

  if (tracking.count >= maxMessages) {
    // Delete spam messages
    await message.channel.messages.fetch({ limit: maxMessages }).then(msgs => {
      const userMsgs = msgs.filter(m => m.author.id === message.author.id);
      message.channel.bulkDelete(userMsgs, true).catch(() => {});
    }).catch(() => {});

    tracking.warnCount++;
    tracking.count = 0;
    spamCache.set(key, tracking);

    if (tracking.warnCount >= warnThreshold) {
      // Timeout the user
      const timeoutMs = muteMinutes * 60 * 1000;
      await message.member.timeout(timeoutMs, 'GR BOT Anti-Spam').catch(() => {});

      await message.channel.send({
        embeds: [errorEmbed('🛡️ Anti-Spam', `${message.author} has been timed out for **${muteMinutes} minutes** for spamming.`)],
      }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));

      await logger.log({
        action: '🛡️ Anti-Spam: User Timed Out',
        type: 'error',
        user: message.author,
        details: `Auto-timed out for **${muteMinutes} minutes** due to repeated spam.`,
      });

      // Reset warn count after action
      tracking.warnCount = 0;
      spamCache.set(key, tracking);
    } else {
      await message.channel.send({
        embeds: [errorEmbed('🛡️ Anti-Spam Warning', `${message.author}, please stop spamming! Warning **${tracking.warnCount}/${warnThreshold}**.`)],
      }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));

      await logger.log({
        action: '🛡️ Anti-Spam: Warning Issued',
        type: 'warning',
        user: message.author,
        details: `Spam warning **${tracking.warnCount}/${warnThreshold}** in ${message.channel}`,
      });
    }

    return true; // Was spam
  }

  return false;
}

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot || !message.guild) return;

    // ─── Anti-Spam Check ────────────────────────────────────────────────────
    const wasSpam = await handleAntiSpam(message);
    if (wasSpam) return;

    // ─── Embed Builder (!embed) ──────────────────────────────────────────────
    if (message.content.startsWith('!embed')) {
      const embedCmd = message.client.prefixCommands.get('embed');
      if (embedCmd) {
        const args = message.content.slice('!embed'.length).trim().split(/\s+/);
        try {
          await embedCmd.execute(message, args);
        } catch (err) {
          logger.error(`!embed error: ${err.message}`);
        }
        return;
      }
    }

    // ─── Prefix Commands (.) ─────────────────────────────────────────────────
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const command = message.client.prefixCommands.get(commandName) ||
      message.client.prefixCommands.find(c => c.aliases?.includes(commandName));

    if (!command) return;

    try {
      await command.execute(message, args);
    } catch (err) {
      logger.error(`Prefix command error (${commandName}): ${err.message}`);
      await logger.log({
        action: '🔴 Prefix Command Error',
        type: 'error',
        user: message.author,
        details: `Command: \`${config.prefix}${commandName}\`\nError: ${err.message}`,
      });
      await message.reply({ embeds: [errorEmbed('Command Error', 'Something went wrong. Please try again.')] }).catch(() => {});
    }
  },
};
