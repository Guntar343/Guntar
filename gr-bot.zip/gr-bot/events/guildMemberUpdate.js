// events/guildMemberUpdate.js - Log role changes
const { Events } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildMemberUpdate,
  async execute(oldMember, newMember) {
    const oldRoles = oldMember.roles.cache;
    const newRoles = newMember.roles.cache;

    // Detect added roles
    const added = newRoles.filter(r => !oldRoles.has(r.id));
    // Detect removed roles
    const removed = oldRoles.filter(r => !newRoles.has(r.id));

    if (added.size > 0) {
      await logger.log({
        action: '🎭 Role Added',
        type: 'info',
        user: newMember.user,
        details: `Roles added: ${added.map(r => `**${r.name}**`).join(', ')}`,
      });
    }

    if (removed.size > 0) {
      await logger.log({
        action: '🎭 Role Removed',
        type: 'warning',
        user: newMember.user,
        details: `Roles removed: ${removed.map(r => `**${r.name}**`).join(', ')}`,
      });
    }
  },
};
