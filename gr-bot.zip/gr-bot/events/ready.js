// events/ready.js - Bot ready event
const { Events, ActivityType } = require('discord.js');
const logger = require('../utils/logger');
const config = require('../config/config');
const { reminders } = require('../database/database');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    logger.info(`${config.botName} is online as ${client.user.tag}`);
    logger.init(client);

    // Set bot activity
    client.user.setPresence({
      activities: [{ name: 'GR BOT | /help', type: ActivityType.Watching }],
      status: 'online',
    });

    // Start reminder scheduler
    setInterval(async () => {
      const due = reminders.getDue();
      for (const reminder of due) {
        try {
          const channel = await client.channels.fetch(reminder.channel_id).catch(() => null);
          if (channel) {
            const { createEmbed } = require('../utils/embeds');
            const embed = createEmbed({
              title: '⏰ Reminder!',
              description: reminder.message,
              color: config.embedColor.info,
            });
            await channel.send({ content: `<@${reminder.user_id}>`, embeds: [embed] });
          }
          reminders.markSent(reminder.id);
        } catch (err) {
          logger.error(`Reminder failed: ${err.message}`);
        }
      }
    }, 15000); // Check every 15 seconds
  },
};
