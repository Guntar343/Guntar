// events/interactionCreate.js - Handle slash commands + buttons
const { Events } = require('discord.js');
const { openTicket, closeTicket } = require('../services/ticketService');
const { errorEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    // ─── Slash Commands ──────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.slashCommands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (err) {
        logger.error(`Slash command error (${interaction.commandName}): ${err.message}`);
        await logger.log({
          action: '🔴 Command Error',
          type: 'error',
          user: interaction.user,
          details: `Command: \`/${interaction.commandName}\`\nError: ${err.message}`,
        });

        const errorReply = { embeds: [errorEmbed('Command Error', 'Something went wrong. Please try again.')], ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorReply).catch(() => {});
        } else {
          await interaction.reply(errorReply).catch(() => {});
        }
      }
    }

    // ─── Button Interactions ─────────────────────────────────────────────────
    if (interaction.isButton()) {
      const { customId } = interaction;

      // Ticket open buttons
      if (customId === 'ticket_purchase_ped') {
        await openTicket(interaction, 'purchase_ped');
      } else if (customId === 'ticket_general_question') {
        await openTicket(interaction, 'general_question');
      } else if (customId === 'ticket_close') {
        await closeTicket(interaction);
      }
    }
  },
};
