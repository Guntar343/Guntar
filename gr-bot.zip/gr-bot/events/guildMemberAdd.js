// events/guildMemberAdd.js - Welcome new members
const { Events } = require('discord.js');
const { createEmbed } = require('../utils/embeds');
const config = require('../config/config');
const logger = require('../utils/logger');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    const guild = member.guild;
    const user = member.user;

    // ─── Auto Role ──────────────────────────────────────────────────────────
    if (config.roles.autoRole && config.roles.autoRole !== 'AUTO_ROLE_ID') {
      const role = guild.roles.cache.get(config.roles.autoRole);
      if (role) {
        await member.roles.add(role).catch(err => logger.error(`Auto-role failed: ${err.message}`));
      }
    }

    // ─── Welcome Embed ──────────────────────────────────────────────────────
    if (!config.channels.welcome || config.channels.welcome === 'WELCOME_CHANNEL_ID') return;

    const welcomeChannel = guild.channels.cache.get(config.channels.welcome);
    if (!welcomeChannel) return;

    const memberCount = guild.memberCount;

    const embed = createEmbed({
      title: `👋 Welcome to ${guild.name}!`,
      description:
        `Hey ${user}, we're glad to have you here!\n\n` +
        `${config.welcome.message}\n\n` +
        `> You are our **${memberCount}th** member!`,
      color: config.embedColor.success,
      thumbnail: user.displayAvatarURL({ dynamic: true, size: 256 }),
      image: config.welcome.bannerUrl !== 'https://i.imgur.com/GR_BANNER_URL.png' ? config.welcome.bannerUrl : null,
      fields: [
        { name: '👤 Username', value: user.tag, inline: true },
        { name: '🆔 User ID', value: user.id, inline: true },
        { name: '📅 Account Age', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
      ],
      footer: true,
      timestamp: true,
    });

    await welcomeChannel.send({ content: `${user}`, embeds: [embed] }).catch(err =>
      logger.error(`Welcome message failed: ${err.message}`)
    );

    // Log the join
    await logger.log({
      action: '📥 Member Joined',
      type: 'success',
      user,
      details: `**${user.tag}** joined the server. (Member #${memberCount})`,
    });
  },
};
