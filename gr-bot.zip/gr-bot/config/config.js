// config/config.js - GR BOT Central Configuration
// All IDs and settings are managed here — no hardcoded values elsewhere

module.exports = {
  // ─── Bot Identity ───────────────────────────────────────────────────────────
  botName: 'GR BOT',
  botVersion: '1.0.0',
  embedColor: {
    primary: '#5865F2',   // Discord Blurple
    success: '#57F287',   // Green
    error: '#ED4245',     // Red
    warning: '#FEE75C',   // Yellow
    info: '#5865F2',      // Blue
    neutral: '#2B2D31',   // Dark
  },
  botFooter: 'GR BOT • Powered by GR Systems',
  botIconUrl: 'https://cdn.discordapp.com/embed/avatars/0.png', // Replace with your bot icon URL

  // ─── Channel IDs ────────────────────────────────────────────────────────────
  channels: {
    welcome: 'WELCOME_CHANNEL_ID',          // Welcome messages
    logs: 'LOGS_CHANNEL_ID',                // All bot action logs
    ticketCategory: 'TICKET_CATEGORY_ID',   // Category for ticket channels
    ticketPanel: 'TICKET_PANEL_CHANNEL_ID', // Where ticket creation panel is sent
  },

  // ─── Role IDs ───────────────────────────────────────────────────────────────
  roles: {
    autoRole: 'AUTO_ROLE_ID',         // Role given on member join
    staff: 'STAFF_ROLE_ID',           // Staff role (embed builder, etc.)
    admin: 'ADMIN_ROLE_ID',           // Admin role
    mod: 'MOD_ROLE_ID',               // Moderator role
    ticketSupport: 'SUPPORT_ROLE_ID', // Can see all tickets
  },

  // ─── Ticket Settings ─────────────────────────────────────────────────────────
  tickets: {
    maxOpen: 1,               // Max open tickets per user
    closeDelay: 5000,         // ms before channel deletion after close
    autoCloseHours: 48,       // Auto-close inactive tickets after N hours
  },

  // ─── Anti-Spam Settings ──────────────────────────────────────────────────────
  antiSpam: {
    enabled: true,
    maxMessages: 5,           // Messages before flagging
    timeWindow: 3000,         // ms window to count messages
    muteMinutes: 5,           // Timeout duration in minutes
    warnThreshold: 3,         // Warnings before auto-timeout
  },

  // ─── Economy Settings ────────────────────────────────────────────────────────
  economy: {
    dailyAmount: 100,         // Daily reward
    dailyCooldown: 86400000,  // 24h in ms
    startingBalance: 0,
    currency: '💰',
    currencyName: 'coins',
  },

  // ─── Warning/Moderation ──────────────────────────────────────────────────────
  moderation: {
    warnLimit: 3,             // Warnings before auto-action
    warnAction: 'timeout',    // 'timeout' | 'kick' | 'ban'
    warnTimeoutMinutes: 60,
  },

  // ─── Welcome Settings ────────────────────────────────────────────────────────
  welcome: {
    bannerUrl: 'https://i.imgur.com/GR_BANNER_URL.png', // Replace with your banner
    message: 'Welcome to the server! Please read the rules and enjoy your stay.',
  },

  // ─── Prefix Commands ─────────────────────────────────────────────────────────
  prefix: '.',

  // ─── Database ────────────────────────────────────────────────────────────────
  database: {
    path: './database/grbot.db',
  },
};
