// index.js - GR BOT Entry Point
require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const logger = require('./utils/logger');
const { loadSlashCommands, loadPrefixCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');

// ─── Validate Environment ─────────────────────────────────────────────────────
if (!process.env.DISCORD_TOKEN) {
  logger.error('Missing DISCORD_TOKEN in .env file!');
  process.exit(1);
}

if (!process.env.CLIENT_ID) {
  logger.error('Missing CLIENT_ID in .env file!');
  process.exit(1);
}

// ─── Create Client ─────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
});

// ─── Initialize Database ──────────────────────────────────────────────────────
logger.info('Initializing GR BOT database...');
require('./database/database'); // Initialize tables on startup
logger.info('Database ready.');

// ─── Load Commands & Events ───────────────────────────────────────────────────
loadSlashCommands(client);
loadPrefixCommands(client);
loadEvents(client);

// ─── Global Error Handlers ─────────────────────────────────────────────────────
process.on('unhandledRejection', err => {
  logger.error(`Unhandled rejection: ${err.message}`);
});

process.on('uncaughtException', err => {
  logger.error(`Uncaught exception: ${err.message}`);
  process.exit(1);
});

// ─── Connect to Discord ────────────────────────────────────────────────────────
logger.info('Connecting GR BOT to Discord...');
client.login(process.env.DISCORD_TOKEN).catch(err => {
  logger.error(`Failed to login: ${err.message}`);
  process.exit(1);
});
