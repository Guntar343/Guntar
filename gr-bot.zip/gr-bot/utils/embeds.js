// utils/embeds.js - GR BOT Embed Builder Utility
const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

/**
 * Creates a branded GR BOT embed
 * @param {object} options
 * @returns {EmbedBuilder}
 */
function createEmbed({
  title,
  description,
  color = config.embedColor.primary,
  fields = [],
  thumbnail,
  image,
  author,
  footer = true,
  timestamp = true,
  url,
} = {}) {
  const embed = new EmbedBuilder().setColor(color);

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (thumbnail) embed.setThumbnail(thumbnail);
  if (image) embed.setImage(image);
  if (url) embed.setURL(url);
  if (author) embed.setAuthor(author);
  if (fields.length > 0) embed.addFields(fields);
  if (timestamp) embed.setTimestamp();
  if (footer) {
    embed.setFooter({
      text: config.botFooter,
      iconURL: config.botIconUrl,
    });
  }

  return embed;
}

function successEmbed(title, description) {
  return createEmbed({ title: `✅ ${title}`, description, color: config.embedColor.success });
}

function errorEmbed(title, description) {
  return createEmbed({ title: `❌ ${title}`, description, color: config.embedColor.error });
}

function warningEmbed(title, description) {
  return createEmbed({ title: `⚠️ ${title}`, description, color: config.embedColor.warning });
}

function infoEmbed(title, description) {
  return createEmbed({ title: `ℹ️ ${title}`, description, color: config.embedColor.info });
}

// Log embed for the logs channel
function logEmbed({ action, type = 'info', user, details, moderator }) {
  const colorMap = {
    success: config.embedColor.success,
    error: config.embedColor.error,
    warning: config.embedColor.warning,
    info: config.embedColor.info,
  };

  const fields = [];
  if (user) {
    fields.push({ name: '👤 User', value: `${user.tag || user} (${user.id || 'N/A'})`, inline: true });
  }
  if (moderator) {
    fields.push({ name: '🛡️ Moderator', value: `${moderator.tag || moderator} (${moderator.id || 'N/A'})`, inline: true });
  }
  if (details) {
    fields.push({ name: '📝 Details', value: details });
  }

  return createEmbed({
    title: `📋 ${action}`,
    color: colorMap[type] || colorMap.info,
    fields,
  });
}

module.exports = { createEmbed, successEmbed, errorEmbed, warningEmbed, infoEmbed, logEmbed };
