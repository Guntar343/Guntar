// utils/logger.js - GR BOT Logging Service
const config = require('../config/config');
const { logEmbed } = require('./embeds');

let _client = null;

function init(client) {
  _client = client;
}

/**
 * Send a log embed to the configured logs channel
 */
async function log({ action, type = 'info', user, moderator, details }) {
  if (!_client) return;

  try {
    const logsChannel = await _client.channels.fetch(config.channels.logs).catch(() => null);
    if (!logsChannel) return;

    const embed = logEmbed({ action, type, user, moderator, details });
    await logsChannel.send({ embeds: [embed] });
  } catch (err) {
    console.error(`[GR BOT] Failed to send log: ${err.message}`);
  }
}

// Console-level logs with timestamp
function info(msg) { console.log(`[GR BOT][INFO] ${new Date().toISOString()} — ${msg}`); }
function warn(msg) { console.warn(`[GR BOT][WARN] ${new Date().toISOString()} — ${msg}`); }
function error(msg) { console.error(`[GR BOT][ERROR] ${new Date().toISOString()} — ${msg}`); }

module.exports = { init, log, info, warn, error };
