// utils/permissions.js - GR BOT Permission Helpers
const config = require('../config/config');

function isAdmin(member) {
  return (
    member.permissions.has('Administrator') ||
    member.roles.cache.has(config.roles.admin)
  );
}

function isMod(member) {
  return (
    isAdmin(member) ||
    member.permissions.has('ModerateMembers') ||
    member.roles.cache.has(config.roles.mod)
  );
}

function isStaff(member) {
  return (
    isMod(member) ||
    member.roles.cache.has(config.roles.staff)
  );
}

function isTicketSupport(member) {
  return (
    isMod(member) ||
    member.roles.cache.has(config.roles.ticketSupport)
  );
}

module.exports = { isAdmin, isMod, isStaff, isTicketSupport };
