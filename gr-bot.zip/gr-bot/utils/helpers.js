// utils/helpers.js - GR BOT General Helpers

/**
 * Format a number with padding zeros for ticket IDs
 * e.g. 1 → "001", 42 → "042"
 */
function formatTicketNumber(num) {
  return String(num).padStart(3, '0');
}

/**
 * Parse a duration string into milliseconds
 * e.g. "10m", "2h", "1d"
 */
function parseDuration(str) {
  const units = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  const match = str.match(/^(\d+)([smhd])$/);
  if (!match) return null;
  return parseInt(match[1]) * (units[match[2]] || 0);
}

/**
 * Format milliseconds into a readable string
 */
function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ${m % 60}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

/**
 * Validate a Discord user ID
 */
function isValidSnowflake(id) {
  return /^\d{17,20}$/.test(id);
}

/**
 * Truncate a string to a max length
 */
function truncate(str, max = 1024) {
  if (!str) return 'N/A';
  return str.length > max ? `${str.substring(0, max - 3)}...` : str;
}

/**
 * Format a Unix timestamp for Discord
 */
function discordTimestamp(date, style = 'R') {
  const unix = Math.floor((date instanceof Date ? date : new Date(date)).getTime() / 1000);
  return `<t:${unix}:${style}>`;
}

module.exports = { formatTicketNumber, parseDuration, formatDuration, isValidSnowflake, truncate, discordTimestamp };
