// handlers/commandHandler.js - GR BOT Command Loader
const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');
const logger = require('../utils/logger');

function loadSlashCommands(client) {
  client.slashCommands = new Collection();
  const slashDir = path.join(__dirname, '../commands/slash');
  const files = fs.readdirSync(slashDir).filter(f => f.endsWith('.js'));

  for (const file of files) {
    try {
      const command = require(path.join(slashDir, file));
      if (!command.data || !command.execute) {
        logger.warn(`Slash command ${file} missing data or execute.`);
        continue;
      }
      client.slashCommands.set(command.data.name, command);
      logger.info(`Loaded slash command: /${command.data.name}`);
    } catch (err) {
      logger.error(`Failed to load slash command ${file}: ${err.message}`);
    }
  }
}

function loadPrefixCommands(client) {
  client.prefixCommands = new Collection();
  const prefixDir = path.join(__dirname, '../commands/prefix');
  const files = fs.readdirSync(prefixDir).filter(f => f.endsWith('.js'));

  for (const file of files) {
    try {
      const command = require(path.join(prefixDir, file));
      if (!command.name || !command.execute) {
        logger.warn(`Prefix command ${file} missing name or execute.`);
        continue;
      }
      client.prefixCommands.set(command.name, command);
      if (command.aliases) {
        for (const alias of command.aliases) {
          client.prefixCommands.set(alias, command);
        }
      }
      logger.info(`Loaded prefix command: .${command.name}`);
    } catch (err) {
      logger.error(`Failed to load prefix command ${file}: ${err.message}`);
    }
  }
}

module.exports = { loadSlashCommands, loadPrefixCommands };
