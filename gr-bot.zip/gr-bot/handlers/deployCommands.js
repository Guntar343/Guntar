// handlers/deployCommands.js - Deploy slash commands to Discord
require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID; // Optional: for guild-scoped (instant) deployment

if (!token || !clientId) {
  console.error('[GR BOT] Missing DISCORD_TOKEN or CLIENT_ID in .env');
  process.exit(1);
}

const commands = [];
const slashDir = path.join(__dirname, '../commands/slash');
const files = fs.readdirSync(slashDir).filter(f => f.endsWith('.js'));

for (const file of files) {
  const command = require(path.join(slashDir, file));
  if (command.data) {
    commands.push(command.data.toJSON());
    console.log(`[GR BOT] Queued: /${command.data.name}`);
  }
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`[GR BOT] Deploying ${commands.length} slash commands...`);

    let data;
    if (guildId) {
      // Guild-scoped: instant update (for development)
      data = await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`[GR BOT] ✅ Successfully deployed ${data.length} commands to guild ${guildId}`);
    } else {
      // Global: up to 1 hour to propagate
      data = await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log(`[GR BOT] ✅ Successfully deployed ${data.length} global commands`);
    }
  } catch (err) {
    console.error('[GR BOT] Deploy failed:', err);
  }
})();
