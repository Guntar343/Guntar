// database/database.js - GR BOT SQLite Database Layer
const Database = require('better-sqlite3');
const config = require('../config/config');
const path = require('path');
const fs = require('fs');

// Ensure database directory exists
const dbDir = path.dirname(path.resolve(config.database.path));
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.resolve(config.database.path));

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Initialize Tables ────────────────────────────────────────────────────────
db.exec(`
  -- Ticket counter (persistent sequential IDs)
  CREATE TABLE IF NOT EXISTS ticket_counter (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    count INTEGER NOT NULL DEFAULT 0
  );

  -- Insert initial counter row
  INSERT OR IGNORE INTO ticket_counter (id, count) VALUES (1, 0);

  -- Ticket metadata
  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_number INTEGER NOT NULL UNIQUE,
    channel_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at INTEGER NOT NULL DEFAULT (unixepoch()),
    closed_at INTEGER,
    closed_by TEXT
  );

  -- Economy balances
  CREATE TABLE IF NOT EXISTS economy (
    user_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    balance INTEGER NOT NULL DEFAULT 0,
    last_daily INTEGER DEFAULT 0,
    total_earned INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );

  -- Warning/moderation cases
  CREATE TABLE IF NOT EXISTS mod_cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    action TEXT NOT NULL,
    reason TEXT,
    duration INTEGER,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  );

  -- Warning points
  CREATE TABLE IF NOT EXISTS warnings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    moderator_id TEXT NOT NULL,
    reason TEXT,
    points INTEGER NOT NULL DEFAULT 1,
    active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL DEFAULT (unixepoch())
  );

  -- Anti-spam cooldowns
  CREATE TABLE IF NOT EXISTS spam_tracking (
    user_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    message_count INTEGER NOT NULL DEFAULT 0,
    window_start INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
    warn_count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );

  -- Reminders
  CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    message TEXT NOT NULL,
    remind_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (unixepoch()),
    sent INTEGER NOT NULL DEFAULT 0
  );
`);

// ─── Ticket Counter Methods ───────────────────────────────────────────────────
const ticketCounter = {
  getNext() {
    const increment = db.prepare(`
      UPDATE ticket_counter SET count = count + 1 WHERE id = 1 RETURNING count
    `);
    const result = increment.get();
    return result.count;
  },
  getCurrent() {
    return db.prepare('SELECT count FROM ticket_counter WHERE id = 1').get().count;
  },
};

// ─── Ticket Methods ───────────────────────────────────────────────────────────
const tickets = {
  create(ticketNumber, channelId, guildId, ownerId, type) {
    return db.prepare(`
      INSERT INTO tickets (ticket_number, channel_id, guild_id, owner_id, type)
      VALUES (?, ?, ?, ?, ?)
    `).run(ticketNumber, channelId, guildId, ownerId, type);
  },
  getByChannel(channelId) {
    return db.prepare('SELECT * FROM tickets WHERE channel_id = ?').get(channelId);
  },
  getByOwner(ownerId, guildId) {
    return db.prepare(`
      SELECT * FROM tickets WHERE owner_id = ? AND guild_id = ? AND status = 'open'
    `).all(ownerId, guildId);
  },
  close(channelId, closedBy) {
    return db.prepare(`
      UPDATE tickets SET status = 'closed', closed_at = unixepoch(), closed_by = ?
      WHERE channel_id = ?
    `).run(closedBy, channelId);
  },
  getAll(guildId, status = 'open') {
    return db.prepare('SELECT * FROM tickets WHERE guild_id = ? AND status = ?').all(guildId, status);
  },
};

// ─── Economy Methods ──────────────────────────────────────────────────────────
const economy = {
  get(userId, guildId) {
    let record = db.prepare('SELECT * FROM economy WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
    if (!record) {
      db.prepare('INSERT OR IGNORE INTO economy (user_id, guild_id, balance) VALUES (?, ?, 0)').run(userId, guildId);
      record = db.prepare('SELECT * FROM economy WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
    }
    return record;
  },
  setBalance(userId, guildId, amount) {
    db.prepare('INSERT OR IGNORE INTO economy (user_id, guild_id, balance) VALUES (?, ?, 0)').run(userId, guildId);
    return db.prepare('UPDATE economy SET balance = ? WHERE user_id = ? AND guild_id = ?').run(amount, userId, guildId);
  },
  addBalance(userId, guildId, amount) {
    db.prepare('INSERT OR IGNORE INTO economy (user_id, guild_id, balance) VALUES (?, ?, 0)').run(userId, guildId);
    return db.prepare(`
      UPDATE economy SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ? AND guild_id = ?
    `).run(amount, amount > 0 ? amount : 0, userId, guildId);
  },
  removeBalance(userId, guildId, amount) {
    const record = this.get(userId, guildId);
    const newBalance = Math.max(0, record.balance - amount);
    return db.prepare('UPDATE economy SET balance = ? WHERE user_id = ? AND guild_id = ?').run(newBalance, userId, guildId);
  },
  setLastDaily(userId, guildId) {
    db.prepare('INSERT OR IGNORE INTO economy (user_id, guild_id, balance) VALUES (?, ?, 0)').run(userId, guildId);
    return db.prepare('UPDATE economy SET last_daily = ? WHERE user_id = ? AND guild_id = ?').run(Date.now(), userId, guildId);
  },
  getLeaderboard(guildId, limit = 10) {
    return db.prepare('SELECT * FROM economy WHERE guild_id = ? ORDER BY balance DESC LIMIT ?').all(guildId, limit);
  },
};

// ─── Moderation Methods ───────────────────────────────────────────────────────
const moderation = {
  addCase(guildId, userId, moderatorId, action, reason, duration = null) {
    return db.prepare(`
      INSERT INTO mod_cases (guild_id, user_id, moderator_id, action, reason, duration)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(guildId, userId, moderatorId, action, reason, duration);
  },
  getCases(userId, guildId) {
    return db.prepare('SELECT * FROM mod_cases WHERE user_id = ? AND guild_id = ? ORDER BY created_at DESC').all(userId, guildId);
  },
  addWarning(guildId, userId, moderatorId, reason) {
    return db.prepare(`
      INSERT INTO warnings (guild_id, user_id, moderator_id, reason) VALUES (?, ?, ?, ?)
    `).run(guildId, userId, moderatorId, reason);
  },
  getWarnings(userId, guildId) {
    return db.prepare(`
      SELECT * FROM warnings WHERE user_id = ? AND guild_id = ? AND active = 1 ORDER BY created_at DESC
    `).all(userId, guildId);
  },
  getWarningCount(userId, guildId) {
    return db.prepare(`
      SELECT COUNT(*) as count FROM warnings WHERE user_id = ? AND guild_id = ? AND active = 1
    `).get(userId, guildId).count;
  },
  clearWarnings(userId, guildId) {
    return db.prepare('UPDATE warnings SET active = 0 WHERE user_id = ? AND guild_id = ?').run(userId, guildId);
  },
};

// ─── Spam Tracking Methods ────────────────────────────────────────────────────
const spamTracking = {
  get(userId, guildId) {
    return db.prepare('SELECT * FROM spam_tracking WHERE user_id = ? AND guild_id = ?').get(userId, guildId);
  },
  upsert(userId, guildId, count, windowStart, warnCount) {
    return db.prepare(`
      INSERT INTO spam_tracking (user_id, guild_id, message_count, window_start, warn_count)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id, guild_id) DO UPDATE SET
        message_count = excluded.message_count,
        window_start = excluded.window_start,
        warn_count = excluded.warn_count
    `).run(userId, guildId, count, windowStart, warnCount);
  },
  reset(userId, guildId) {
    return db.prepare(`
      UPDATE spam_tracking SET message_count = 0, window_start = ?, warn_count = 0
      WHERE user_id = ? AND guild_id = ?
    `).run(Date.now(), userId, guildId);
  },
};

// ─── Reminder Methods ─────────────────────────────────────────────────────────
const reminders = {
  create(userId, channelId, guildId, message, remindAt) {
    return db.prepare(`
      INSERT INTO reminders (user_id, channel_id, guild_id, message, remind_at) VALUES (?, ?, ?, ?, ?)
    `).run(userId, channelId, guildId, message, remindAt);
  },
  getDue() {
    return db.prepare('SELECT * FROM reminders WHERE remind_at <= ? AND sent = 0').all(Date.now());
  },
  markSent(id) {
    return db.prepare('UPDATE reminders SET sent = 1 WHERE id = ?').run(id);
  },
};

module.exports = { db, ticketCounter, tickets, economy, moderation, spamTracking, reminders };
