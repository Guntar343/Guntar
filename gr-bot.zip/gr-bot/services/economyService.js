// services/economyService.js - GR BOT Economy Business Logic
const { economy } = require('../database/database');
const config = require('../config/config');
const logger = require('../utils/logger');

const curr = config.economy.currency;
const currName = config.economy.currencyName;

function formatBalance(amount) {
  return `${curr} **${amount.toLocaleString()}** ${currName}`;
}

async function getBalance(userId, guildId) {
  const record = economy.get(userId, guildId);
  return record.balance;
}

async function pay(fromUserId, toUserId, guildId, amount, fromUser, toUser) {
  if (amount <= 0) return { success: false, error: 'Amount must be greater than 0.' };
  const from = economy.get(fromUserId, guildId);
  if (from.balance < amount) return { success: false, error: 'Insufficient balance.' };

  economy.removeBalance(fromUserId, guildId, amount);
  economy.addBalance(toUserId, guildId, amount);

  await logger.log({
    action: 'Economy Transaction',
    type: 'info',
    user: fromUser,
    details: `Sent ${formatBalance(amount)} to ${toUser?.tag || toUserId}`,
  });

  return { success: true };
}

async function daily(userId, guildId, user) {
  const record = economy.get(userId, guildId);
  const now = Date.now();
  const cooldown = config.economy.dailyCooldown;

  if (record.last_daily && now - record.last_daily < cooldown) {
    const remaining = cooldown - (now - record.last_daily);
    return { success: false, remaining };
  }

  economy.addBalance(userId, guildId, config.economy.dailyAmount);
  economy.setLastDaily(userId, guildId);

  await logger.log({
    action: 'Daily Reward',
    type: 'success',
    user,
    details: `Claimed daily reward of ${formatBalance(config.economy.dailyAmount)}`,
  });

  return { success: true, amount: config.economy.dailyAmount };
}

async function adminAdd(userId, guildId, amount, targetUser, moderator) {
  if (amount <= 0) return { success: false, error: 'Amount must be greater than 0.' };
  economy.addBalance(userId, guildId, amount);

  await logger.log({
    action: 'Admin: Add Money',
    type: 'info',
    user: targetUser,
    moderator,
    details: `Added ${formatBalance(amount)} to ${targetUser?.tag || userId}`,
  });

  return { success: true };
}

async function adminRemove(userId, guildId, amount, targetUser, moderator) {
  if (amount <= 0) return { success: false, error: 'Amount must be greater than 0.' };
  economy.removeBalance(userId, guildId, amount);

  await logger.log({
    action: 'Admin: Remove Money',
    type: 'warning',
    user: targetUser,
    moderator,
    details: `Removed ${formatBalance(amount)} from ${targetUser?.tag || userId}`,
  });

  return { success: true };
}

module.exports = { getBalance, pay, daily, adminAdd, adminRemove, formatBalance };
