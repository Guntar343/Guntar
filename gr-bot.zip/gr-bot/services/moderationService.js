// services/moderationService.js - GR BOT Moderation Business Logic
const { moderation } = require('../database/database');
const config = require('../config/config');
const logger = require('../utils/logger');
const { formatDuration } = require('../utils/helpers');

async function ban(guild, targetMember, moderator, reason = 'No reason provided') {
  await targetMember.ban({ reason: `GR BOT | ${moderator.tag}: ${reason}` });
  moderation.addCase(guild.id, targetMember.id, moderator.id, 'ban', reason);

  await logger.log({
    action: '🔨 Member Banned',
    type: 'error',
    user: targetMember.user,
    moderator,
    details: `**Reason:** ${reason}`,
  });
}

async function kick(guild, targetMember, moderator, reason = 'No reason provided') {
  await targetMember.kick(`GR BOT | ${moderator.tag}: ${reason}`);
  moderation.addCase(guild.id, targetMember.id, moderator.id, 'kick', reason);

  await logger.log({
    action: '👢 Member Kicked',
    type: 'error',
    user: targetMember.user,
    moderator,
    details: `**Reason:** ${reason}`,
  });
}

async function timeout(guild, targetMember, moderator, durationMs, reason = 'No reason provided') {
  await targetMember.timeout(durationMs, `GR BOT | ${moderator.tag}: ${reason}`);
  moderation.addCase(guild.id, targetMember.id, moderator.id, 'timeout', reason, durationMs);

  await logger.log({
    action: '⏱️ Member Timed Out',
    type: 'warning',
    user: targetMember.user,
    moderator,
    details: `**Duration:** ${formatDuration(durationMs)}\n**Reason:** ${reason}`,
  });
}

async function warn(guild, targetUser, moderator, reason = 'No reason provided') {
  moderation.addWarning(guild.id, targetUser.id, moderator.id, reason);
  const warnCount = moderation.getWarningCount(targetUser.id, guild.id);

  await logger.log({
    action: '⚠️ Member Warned',
    type: 'warning',
    user: targetUser,
    moderator,
    details: `**Reason:** ${reason}\n**Total Warnings:** ${warnCount}`,
  });

  // Auto-punish if threshold reached
  if (warnCount >= config.moderation.warnLimit) {
    const member = await guild.members.fetch(targetUser.id).catch(() => null);
    if (member) {
      if (config.moderation.warnAction === 'timeout') {
        const ms = config.moderation.warnTimeoutMinutes * 60 * 1000;
        await timeout(guild, member, { tag: 'GR BOT Auto-Mod', id: 'AUTO' }, ms, `Auto: Reached ${warnCount} warnings`);
      } else if (config.moderation.warnAction === 'kick') {
        await kick(guild, member, { tag: 'GR BOT Auto-Mod', id: 'AUTO' }, `Auto: Reached ${warnCount} warnings`);
      } else if (config.moderation.warnAction === 'ban') {
        await ban(guild, member, { tag: 'GR BOT Auto-Mod', id: 'AUTO' }, `Auto: Reached ${warnCount} warnings`);
      }
    }
  }

  return warnCount;
}

module.exports = { ban, kick, timeout, warn };
