// services/ticketService.js - GR BOT Ticket Business Logic
const {
  PermissionFlagsBits,
  ChannelType,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} = require('discord.js');
const config = require('../config/config');
const { ticketCounter, tickets } = require('../database/database');
const { createEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { formatTicketNumber } = require('../utils/helpers');
const logger = require('../utils/logger');

const TICKET_TYPES = {
  purchase_ped: { label: '🎫 Purchase PED', emoji: '🎫', color: config.embedColor.primary },
  general_question: { label: '❓ General Question', emoji: '❓', color: config.embedColor.info },
};

/**
 * Create ticket panel with buttons
 */
function createTicketPanel() {
  const embed = createEmbed({
    title: '🎟️ GR BOT Ticket System',
    description:
      '**Need help? Open a ticket below!**\n\n' +
      '🎫 **Purchase PED** — For purchasing in-game currency\n' +
      '❓ **General Question** — For any other questions\n\n' +
      '*One ticket per user at a time.*',
    color: config.embedColor.primary,
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_purchase_ped')
      .setLabel('Purchase PED')
      .setEmoji('🎫')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('ticket_general_question')
      .setLabel('General Question')
      .setEmoji('❓')
      .setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], components: [row] };
}

/**
 * Open a new ticket for a user
 */
async function openTicket(interaction, type) {
  const guild = interaction.guild;
  const user = interaction.user;

  await interaction.deferReply({ ephemeral: true });

  // Check for existing open ticket
  const existing = tickets.getByOwner(user.id, guild.id);
  if (existing.length >= config.tickets.maxOpen) {
    return interaction.editReply({
      embeds: [errorEmbed('Ticket Already Open', `You already have an open ticket! Please close it before opening a new one.`)],
    });
  }

  // Get next ticket number
  const ticketNum = ticketCounter.getNext();
  const ticketName = `ticket-${formatTicketNumber(ticketNum)}`;

  // Build permission overwrites
  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
  ];

  // Add support role if configured
  if (config.roles.ticketSupport && config.roles.ticketSupport !== 'SUPPORT_ROLE_ID') {
    overwrites.push({
      id: config.roles.ticketSupport,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  // Create ticket channel
  const channel = await guild.channels.create({
    name: ticketName,
    type: ChannelType.GuildText,
    parent: config.channels.ticketCategory !== 'TICKET_CATEGORY_ID' ? config.channels.ticketCategory : null,
    permissionOverwrites: overwrites,
    reason: `GR BOT: Ticket opened by ${user.tag}`,
  });

  // Save to DB
  tickets.create(ticketNum, channel.id, guild.id, user.id, type);

  // Send welcome message in ticket
  const typeInfo = TICKET_TYPES[type] || TICKET_TYPES.general_question;
  const welcomeEmbed = createEmbed({
    title: `${typeInfo.emoji} ${typeInfo.label} — #${formatTicketNumber(ticketNum)}`,
    description:
      `Welcome ${user}! Please describe why did you open a ticket and what do you need!\n` +
      `**GR BOT** will respond to you as soon as possible!\n\n` +
      `*Use \`.fc\` to close this ticket.*`,
    color: typeInfo.color,
    thumbnail: user.displayAvatarURL({ dynamic: true }),
    fields: [
      { name: '👤 Opened By', value: `${user} (${user.id})`, inline: true },
      { name: '📋 Type', value: typeInfo.label, inline: true },
      { name: '🔢 Ticket #', value: `#${formatTicketNumber(ticketNum)}`, inline: true },
    ],
  });

  const closeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_close')
      .setLabel('Close Ticket')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({ content: `${user}`, embeds: [welcomeEmbed], components: [closeRow] });

  await interaction.editReply({
    embeds: [successEmbed('Ticket Created!', `Your ticket has been created: ${channel}`)],
  });

  // Log
  await logger.log({
    action: 'Ticket Created',
    type: 'success',
    user,
    details: `Ticket **${ticketName}** (${typeInfo.label}) created in ${channel}`,
  });
}

/**
 * Close a ticket channel
 */
async function closeTicket(interaction) {
  const channel = interaction.channel;
  const user = interaction.user;
  const ticketData = tickets.getByChannel(channel.id);

  if (!ticketData) {
    return interaction.reply({ embeds: [errorEmbed('Not a Ticket', 'This command can only be used in a ticket channel.')], ephemeral: true });
  }

  await interaction.reply({ embeds: [createEmbed({ title: '🔒 Closing Ticket...', description: 'This ticket will be deleted in 5 seconds.', color: config.embedColor.warning })] });

  tickets.close(channel.id, user.id);

  await logger.log({
    action: 'Ticket Closed',
    type: 'error',
    user,
    details: `Ticket **${channel.name}** closed by ${user.tag}`,
  });

  setTimeout(async () => {
    await channel.delete(`GR BOT: Ticket closed by ${user.tag}`).catch(() => {});
  }, config.tickets.closeDelay);
}

module.exports = { createTicketPanel, openTicket, closeTicket, TICKET_TYPES };
