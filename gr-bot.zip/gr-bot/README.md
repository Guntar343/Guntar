# 🤖 GR BOT — Production Discord Bot

A fully production-ready Discord bot built with **Node.js + discord.js v14**, featuring a complete modular architecture with all systems integrated.

---

## 📁 Project Structure

```
gr-bot/
├── index.js                    # Entry point
├── .env.example                # Environment template
├── package.json
│
├── config/
│   └── config.js               # ⚙️ All IDs and settings (edit this!)
│
├── database/
│   └── database.js             # SQLite database + all DB methods
│
├── commands/
│   ├── slash/                  # Slash commands (/)
│   │   ├── clear.js
│   │   ├── ban.js
│   │   ├── kick.js
│   │   ├── timeout.js
│   │   ├── warn.js
│   │   ├── userinfo.js
│   │   ├── serverinfo.js
│   │   ├── avatar.js
│   │   ├── poll.js
│   │   ├── remind.js
│   │   └── ticketpanel.js
│   │
│   └── prefix/                 # Prefix commands (. and !)
│       ├── fc.js               # Close ticket
│       ├── add.js              # Add user to ticket
│       ├── remove.js           # Remove user from ticket
│       ├── balance.js          # Economy
│       ├── pay.js
│       ├── daily.js
│       ├── addmoney.js         # Admin economy
│       ├── removemoney.js
│       ├── role.js             # Role management
│       └── embed.js            # !embed builder (staff)
│
├── events/
│   ├── ready.js                # Bot startup + reminder scheduler
│   ├── guildMemberAdd.js       # Welcome + auto-role
│   ├── guildMemberUpdate.js    # Role change logs
│   ├── interactionCreate.js    # Slash commands + buttons
│   └── messageCreate.js        # Prefix commands + anti-spam
│
├── handlers/
│   ├── commandHandler.js       # Loads all commands
│   ├── eventHandler.js         # Loads all events
│   └── deployCommands.js       # Deploys slash commands to Discord
│
├── services/
│   ├── ticketService.js        # Ticket business logic
│   ├── economyService.js       # Economy business logic
│   └── moderationService.js    # Moderation business logic
│
└── utils/
    ├── embeds.js               # Embed builder utility
    ├── logger.js               # Console + Discord logging
    ├── permissions.js          # Permission helpers
    └── helpers.js              # General utilities
```

---

## 🚀 Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
```
Edit `.env`:
```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here   # Optional: for instant guild-scoped deployment
```

### 3. Configure the Bot
Edit `config/config.js` and fill in your channel IDs, role IDs, and other settings:

```js
channels: {
  welcome: 'YOUR_WELCOME_CHANNEL_ID',
  logs: 'YOUR_LOGS_CHANNEL_ID',
  ticketCategory: 'YOUR_TICKET_CATEGORY_ID',
},
roles: {
  autoRole: 'YOUR_AUTO_ROLE_ID',
  staff: 'YOUR_STAFF_ROLE_ID',
  admin: 'YOUR_ADMIN_ROLE_ID',
  mod: 'YOUR_MOD_ROLE_ID',
},
```

### 4. Deploy Slash Commands
```bash
node handlers/deployCommands.js
```

### 5. Start the Bot
```bash
node index.js
# or for development:
npm run dev
```

---

## 🎟️ Ticket System

1. Run `/ticketpanel` in your desired channel — this sends the ticket creation panel
2. Users click buttons to open tickets
3. Tickets are named sequentially: `ticket-001`, `ticket-002`, etc.
4. Counter persists in the database (survives restarts)

**Inside a ticket:**
- `.fc` — Close ticket
- `.add <USER_ID>` — Add user to ticket
- `.remove <USER_ID>` — Remove user from ticket

---

## 🧾 Embed Builder

**Staff only:**
```
!embed Title | Subtitle | Content goes here
```
The bot deletes the command message and posts the styled embed.

---

## 💰 Economy Commands

| Command | Description |
|---------|-------------|
| `.balance` / `.bal` | Check balance |
| `.pay @user <amount>` | Send money |
| `.daily` | Claim daily reward |
| `.addmoney @user <amount>` | Admin: add money |
| `.removemoney @user <amount>` | Admin: remove money |

---

## 🛡️ Moderation Commands

| Command | Description |
|---------|-------------|
| `/ban @user [reason]` | Ban member |
| `/kick @user [reason]` | Kick member |
| `/timeout @user <time> [reason]` | Timeout member (e.g. `10m`, `2h`) |
| `/warn @user [reason]` | Warn member |
| `/clear <amount>` | Delete messages |

---

## ⚙️ Utility Commands

| Command | Description |
|---------|-------------|
| `/userinfo [@user]` | User information |
| `/serverinfo` | Server information |
| `/avatar [@user]` | Get avatar |
| `/poll <question> [options]` | Create a poll |
| `/remind <time> <message>` | Set a reminder |

---

## 📊 Logging System

All actions are automatically logged to your configured logs channel with:
- 🟢 Green = Success actions
- 🔴 Red = Destructive actions
- 🔵 Blue = Info actions
- 🟡 Yellow = Warnings

**Events logged:**
- Member join/leave
- Ticket creation/closure
- All moderation actions
- Economy transactions
- Role changes
- Anti-spam triggers
- Embed creation
- Command errors

---

## 🛡️ Anti-Spam System

Configure in `config/config.js`:
```js
antiSpam: {
  enabled: true,
  maxMessages: 5,       // Messages before flagging
  timeWindow: 3000,     // ms window
  muteMinutes: 5,       // Timeout duration
  warnThreshold: 3,     // Warnings before timeout
}
```

---

## 🗄️ Database (SQLite)

The bot uses **SQLite** via `better-sqlite3` for maximum performance and zero external dependencies.

**Stored data:**
- Ticket counter (persistent sequential IDs)
- Ticket metadata (owner, channel, type, status)
- Economy balances + daily cooldowns
- Moderation cases + warnings
- Spam tracking
- Reminders

Database file: `database/grbot.db` (auto-created on first run)

---

## 🔑 Required Bot Permissions

In Discord Developer Portal, enable:
- ✅ `SERVER MEMBERS INTENT`
- ✅ `MESSAGE CONTENT INTENT`
- ✅ `PRESENCE INTENT`

Bot permissions needed:
- Manage Channels, Manage Roles, Manage Messages
- Kick Members, Ban Members, Moderate Members
- Send Messages, Embed Links, Add Reactions
- Read Message History, View Channels

---

## 📈 Dashboard-Ready Architecture

The service layer (`/services`) is designed for external control:
- `ticketService.js` — All ticket operations
- `economyService.js` — All economy operations  
- `moderationService.js` — All moderation operations

These can be imported by a future Express/Fastify API without modifying bot code.

---

*GR BOT — Built for production. Powered by GR Systems.*
